// Enhanced MainCode.cpp

// This MainCode.cpp serves as the application's entry point, initalizing OpenGL context, manages the main loop
// and coordinating rendering by calling the SceneManager and ViewManager.

#include <iostream>         // For error handling and console output
#include <cstdlib>          // For EXIT_FAILURE macro

#include <GL/glew.h>        // GLEW library for managing OpenGL extensions
#include "GLFW/glfw3.h"     // GLFW library for window creation and input

// GLM Math Header inclusions for 3D math
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"   // Manages all 3D scene content
#include "ViewManager.h"    // Handles view and perspective calculations
#include "ShapeMeshes.h"    // Contains shapes for rendering (not used directly here)
#include "ShaderManager.h"  // Manages GLSL shaders

// Namespace for declaring global variables
namespace
{
	const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones"; // Title of the window
	GLFWwindow* g_Window = nullptr;        // Pointer to main GLFW window
	SceneManager* g_SceneManager = nullptr; // Manages 3D objects and rendering
	ShaderManager* g_ShaderManager = nullptr; // Handles shader loading and usage
	ViewManager* g_ViewManager = nullptr;     // Manages view/projection transformations
}

// Forward declarations
bool InitializeGLFW(); // Initializes GLFW
bool InitializeGLEW(); // Initializes GLEW

// Entry point of the application
int main(int argc, char* argv[])
{
	// Initialize GLFW library
	if (!InitializeGLFW())
		return EXIT_FAILURE;

	// Create the shader manager
	g_ShaderManager = new ShaderManager();
	// Create the view manager with reference to the shader manager
	g_ViewManager = new ViewManager(g_ShaderManager);

	// Create the application window
	g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

	// Initialize GLEW (must come after creating the window)
	if (!InitializeGLEW())
		return EXIT_FAILURE;

	// Load GLSL shaders from external files and activate them
	g_ShaderManager->LoadShaders(
		"../../Utilities/shaders/vertexShader.glsl",
		"../../Utilities/shaders/fragmentShader.glsl");
	g_ShaderManager->use();

	// Create and prepare the 3D scene
	g_SceneManager = new SceneManager(g_ShaderManager);
	g_SceneManager->PrepareScene();

	// Main render loop
	while (!glfwWindowShouldClose(g_Window))
	{
		// Enable depth testing for proper z-order rendering
		glEnable(GL_DEPTH_TEST);

		// Clear screen and depth buffer
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Apply view transformations
		g_ViewManager->PrepareSceneView();

		// Render the 3D objects in the scene
		g_SceneManager->RenderScene();

		// Swap front and back buffers to display the rendered frame
		glfwSwapBuffers(g_Window);

		// Process events such as input or window events
		glfwPollEvents();
	}

	// Clean up dynamically allocated memory
	if (g_SceneManager)
	{
		delete g_SceneManager;
		g_SceneManager = nullptr;
	}
	if (g_ViewManager)
	{
		delete g_ViewManager;
		g_ViewManager = nullptr;
	}
	if (g_ShaderManager)
	{
		delete g_ShaderManager;
		g_ShaderManager = nullptr;
	}

	// Exit the application successfully
	exit(EXIT_SUCCESS);
}

// GLFW initialization with OpenGL version settings
bool InitializeGLFW()
{
	glfwInit();

#ifdef __APPLE__
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

	return true;
}

// GLEW initialization with error checking
bool InitializeGLEW()
{
	GLenum GLEWInitResult = glewInit();
	if (GLEW_OK != GLEWInitResult)
	{
		std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
		return false;
	}

	// Output OpenGL version info
	std::cout << "INFO: OpenGL Successfully Initialized\n";
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;

	return true;
}
