// Enhanced SceneManager.cpp

// This cpp manages loading and rendering the 3D scenes.

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// File-local global constants for shader uniform names
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

// Constructor - Initialize SceneManager with ShaderManager and Meshes
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

// Destructor - Clean up allocated memory
SceneManager::~SceneManager()
{
	m_pShaderManager = nullptr;
	delete m_basicMeshes;
	m_basicMeshes = nullptr;
}

// CreateGLTexture - Load texture image, configure OpenGL texture parameters
// Returns true on success, false on failure.
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0, height = 0, colorChannels = 0;
	GLuint textureID = 0;

	// Flip images vertically on load (OpenGL convention)
	stbi_set_flip_vertically_on_load(true);

	// Load image data
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		std::cout << "Successfully loaded image: " << filename
			<< ", width: " << width << ", height: " << height
			<< ", channels: " << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// Texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// Determine image format (RGB or RGBA)
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Unsupported image channels: " << colorChannels << std::endl;
			stbi_image_free(image);
			return false;
		}

		// Generate mipmaps for efficient minification
		glGenerateMipmap(GL_TEXTURE_2D);

		// Free CPU memory
		stbi_image_free(image);

		// Store texture ID and tag for later use
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image: " << filename << std::endl;
	return false;
}

// BindGLTextures - Bind all loaded textures to their slots
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

// FindTextureID - Returns OpenGL texture ID by tag, or -1 if not found
int SceneManager::FindTextureID(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
			return m_textureIDs[i].ID;
	}
	return -1;
}

// FindTextureSlot - Returns texture slot index by tag, or -1 if not found
int SceneManager::FindTextureSlot(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
			return i;
	}
	return -1;
}

// FindMaterial - Retrieves material properties by tag.
// Returns true if found, false otherwise.
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.empty()) return false;

	for (const auto& mat : m_objectMaterials)
	{
		if (mat.tag == tag)
		{
			material = mat;
			return true;
		}
	}
	return false;
}

// SetTransformations - Builds and sends model matrix to shader
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 scale = glm::scale(scaleXYZ);
	glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 translation = glm::translate(positionXYZ);

	glm::mat4 modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (m_pShaderManager)
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

// SetShaderColor - Pass color values to shader for rendering solid color objects
void SceneManager::SetShaderColor(float red, float green, float blue, float alpha)
{
	glm::vec4 color(red, green, blue, alpha);

	if (m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, color);
	}
}

// SetShaderTexture - Bind texture by tag and send to shader
void SceneManager::SetShaderTexture(std::string textureTag)
{
	int textureSlot = FindTextureSlot(textureTag);
	if (textureSlot == -1)
	{
		std::cout << "Error: Texture with tag '" << textureTag << "' not found!" << std::endl;
		return;
	}

	glActiveTexture(GL_TEXTURE0); // Using texture unit 0
	glBindTexture(GL_TEXTURE_2D, m_textureIDs[textureSlot].ID);

	// Tells shader the texture unit
	m_pShaderManager->setSampler2DValue(g_TextureValueName, 0);
}

// SetTextureUVScale - Send texture UV scaling factors to shader
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (m_pShaderManager)
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

// SetShaderMaterial - Load material properties by tag to shader
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (!m_objectMaterials.empty())
	{
		OBJECT_MATERIAL material;
		if (FindMaterial(materialTag, material))
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

// DefineObjectMaterials - Defines material properties for all
// objects in the scene. You can add or modify materials here.
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL material;

	// Box (shoe box) material
	material.tag = "box_body";
	material.ambientColor = glm::vec3(0.4f, 0.3f, 0.2f);
	material.ambientStrength = 0.5f;
	material.diffuseColor = glm::vec3(0.5f, 0.4f, 0.3f);
	material.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	material.shininess = 16.0f;
	m_objectMaterials.push_back(material);

	// Cylinder (cup) material
	material.tag = "cylinder";
	material.ambientColor = glm::vec3(0.2f, 0.2f, 0.8f);
	material.ambientStrength = 0.4f;
	material.diffuseColor = glm::vec3(0.3f, 0.3f, 0.9f);
	material.specularColor = glm::vec3(0.8f, 0.8f, 1.0f);
	material.shininess = 64.0f;
	m_objectMaterials.push_back(material);

	// Sphere (crystal ball) material
	material.tag = "sphere";
	material.ambientColor = glm::vec3(0.8f, 0.8f, 1.0f);
	material.ambientStrength = 0.6f;
	material.diffuseColor = glm::vec3(0.9f, 0.9f, 1.0f);
	material.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	material.shininess = 128.0f;
	m_objectMaterials.push_back(material);

	// Prism (crystal pyramid) material
	material.tag = "prism";
	material.ambientColor = glm::vec3(0.9f, 0.9f, 0.9f);
	material.ambientStrength = 0.7f;
	material.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	material.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	material.shininess = 128.0f;
	m_objectMaterials.push_back(material);

	// Plane (floor) material
	material.tag = "plane";
	material.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	material.ambientStrength = 0.5f;
	material.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	material.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	material.shininess = 16.0f;
	m_objectMaterials.push_back(material);
}

// SetupSceneLights - Configures the light sources for the scene
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Light 0 - White directional light from above
	m_pShaderManager->setVec3Value("lights[0].position", glm::vec3(0.0f, 10.0f, 0.0f));
	m_pShaderManager->setVec3Value("lights[0].color", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setFloatValue("lights[0].strength", 1.0f);
	m_pShaderManager->setBoolValue("lights[0].isDirectional", true);
	m_pShaderManager->setVec3Value("lights[0].ambient", glm::vec3(0.1f));
	m_pShaderManager->setVec3Value("lights[0].specular", glm::vec3(1.0f));

	// Light 1 - Red point light near objects
	m_pShaderManager->setVec3Value("lights[1].position", glm::vec3(-3.0f, 3.0f, 2.0f));
	m_pShaderManager->setVec3Value("lights[1].color", glm::vec3(1.0f, 0.0f, 0.0f));
	m_pShaderManager->setFloatValue("lights[1].strength", 0.7f);
	m_pShaderManager->setBoolValue("lights[1].isDirectional", false);
	m_pShaderManager->setVec3Value("lights[1].ambient", glm::vec3(0.05f));
	m_pShaderManager->setVec3Value("lights[1].specular", glm::vec3(1.0f));
}

// PrepareScene - Load materials, lights, and basic meshes
void SceneManager::PrepareScene()
{
	DefineObjectMaterials();
	SetupSceneLights();

	// Load meshes once for reuse in the scene
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPlaneMesh();

	// Load textures with tags
	CreateGLTexture("box_texture.jpg", "box_texture");
	CreateGLTexture("cylinder_texture.jpg", "cylinder_texture");
	CreateGLTexture("sphere_texture.jpg", "sphere_texture");
	CreateGLTexture("prism_texture.jpg", "prism_texture");
}

 // RenderScene - Render each object with transformations,
 // materials, and textures
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Render the Box (shoe box)
	scaleXYZ = glm::vec3(2.0f, 1.0f, 1.0f);
	positionXYZ = glm::vec3(0.0f, 0.5f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("box_body");
	SetShaderTexture("box_texture.jpg");
	m_basicMeshes->DrawBoxMesh();

	// Render the Cylinder (cup)
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.5f);
	positionXYZ = glm::vec3(-1.0f, 0.5f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("cylinder");
	SetShaderTexture("cylinder_texture.jpg");
	m_basicMeshes->DrawCylinderMesh();

	// Render the Sphere (crystal ball)
	scaleXYZ = glm::vec3(0.7f);
	positionXYZ = glm::vec3(2.0f, 0.4f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("sphere");
	SetShaderTexture("sphere_texture.jpg");
	m_basicMeshes->DrawSphereMesh();

	// Render the Prism (crystal pyramid)
	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);
	positionXYZ = glm::vec3(0.0f, 0.75f, -3.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("prism");
	SetShaderTexture("prism_texture.jpg");
	m_basicMeshes->DrawPrismMesh();

	// Render the Plane (floor)
	scaleXYZ = glm::vec3(10.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("plane");
	m_basicMeshes->DrawPlaneMesh();
}