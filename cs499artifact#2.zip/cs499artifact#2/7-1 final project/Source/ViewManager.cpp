// Enhanced ViewManager.cpp

// This cpp manages the viewing of 3D objects within the viewport. 

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// Anonymous namespace for file-scoped globals
namespace
{
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";               // View matrix uniform name
	const char* g_ProjectionName = "projection";   // Projection matrix uniform name

	Camera* g_pCamera = nullptr;                   // Camera for navigating 3D scene

	// Mouse state
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Frame timing for smooth camera movement
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// Tracks current projection mode (false = perspective, true = orthographic)
	bool bOrthographicProjection = false;
}

// Constructor - Initializes ViewManager instance
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_pWindow = nullptr;

	// Initialize camera with default position and orientation
	g_pCamera = new Camera();
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;

	bOrthographicProjection = false;
}

// Destructor - Releases dynamic memory
ViewManager::~ViewManager()
{
	m_pShaderManager = nullptr;
	m_pWindow = nullptr;

	if (g_pCamera != nullptr)
	{
		delete g_pCamera;
		g_pCamera = nullptr;
	}
}

// ToggleProjection - Switches between orthographic and
// perspective views dynamically via user input (e.g., key P)
void ViewManager::ToggleProjection()
{
	bOrthographicProjection = !bOrthographicProjection;
}

// CreateDisplayWindow - Initializes OpenGL window via GLFW
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, nullptr, nullptr);
	if (!window)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return nullptr;
	}

	glfwMakeContextCurrent(window);

	// Optional: lock mouse to window
	// glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// Enable alpha blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;
	return window;
}

// Mouse_Position_Callback - Called when user moves mouse
// Used to rotate or orient the 3D camera
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	float xOffset = static_cast<float>(xMousePos - gLastX);
	float yOffset = static_cast<float>(gLastY - yMousePos);  // Inverted Y

	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Rotate camera view
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

// ProcessKeyboardEvents - Handles WASD, Q/E, P input keys
void ViewManager::ProcessKeyboardEvents()
{
	// Exit app on ESC
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(m_pWindow, true);

	// Projection toggle
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
		ToggleProjection();

	if (!g_pCamera) return;

	// Movement control (WASD + Q/E for vertical)
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
}

 // PrepareSceneView - Updates view and projection matrices
 // based on user input and camera state
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// Calculate frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// Respond to any keyboard input
	ProcessKeyboardEvents();

	// Get the current view matrix from camera
	view = g_pCamera->GetViewMatrix();

	// Choose projection type
	if (bOrthographicProjection)
	{
		// Orthographic (flat, non-perspective)
		float left = -10.0f, right = 10.0f;
		float bottom = -10.0f, top = 10.0f;
		float near = 0.1f, far = 100.0f;
		projection = glm::ortho(left, right, bottom, top, near, far);
	}
	else
	{
		// Perspective (realistic 3D)
		projection = glm::perspective(glm::radians(g_pCamera->Zoom),
			static_cast<GLfloat>(WINDOW_WIDTH) / static_cast<GLfloat>(WINDOW_HEIGHT),
			0.1f, 100.0f);
	}

	// Send matrices to the shader
	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setMat4Value(g_ViewName, view);
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}