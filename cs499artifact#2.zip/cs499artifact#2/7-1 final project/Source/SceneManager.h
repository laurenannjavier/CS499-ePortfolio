// Enhanced SceneManager.h

// This header file manages loading and rendering of 3D scenes in OpenGL using modern C++ practices.

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>
#include <unordered_map>
#include <memory>

// SceneManager Prepares and renders 3D scenes, manages shader settings,
// materials, and textures.Enhanced with modern C++ features
// such as smart pointers and STL containers.
// Constructor with dependency injection of ShaderManager
class SceneManager
{
public:
	explicit SceneManager(std::shared_ptr<ShaderManager> pShaderManager);
	~SceneManager();

	// Holds texture information
	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	// Describes object surface material properties
	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// Smart pointer to ShaderManager
	std::shared_ptr<ShaderManager> m_pShaderManager;
	// Smart pointer to basic mesh shapes (cubes, spheres, etc.)
	std::shared_ptr<ShapeMeshes> m_basicMeshes;
	// Map for fast texture lookup by tag
	std::unordered_map<std::string, uint32_t> m_textureMap;
	// Vector storing material definitions
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// Loads texture image and generates OpenGL texture
	bool CreateGLTexture(const char* filename, const std::string& tag);
	// Assigns loaded textures to texture units
	void BindGLTextures();
	// Finds texture ID using map
	int FindTextureID(const std::string& tag);
	// Returns texture slot from internal OpenGL binding
	int FindTextureSlot(const std::string& tag);
	// Retrieves material definition by tag
	bool FindMaterial(const std::string& tag, OBJECT_MATERIAL& material);

	// Applies transformations to shader (scale, rotate, translate)
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// Passes color data to shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// Binds selected texture for rendering
	void SetShaderTexture(const std::string& textureTag);

	// Adjusts UV scale for texture mapping
	void SetTextureUVScale(float u, float v);

	// Passes object material to shader
	void SetShaderMaterial(const std::string& materialTag);

public:
	// User-defined methods to configure and render their scene
	void PrepareScene();
	void RenderScene();

	// Pre-configured lighting setup
	void SetupSceneLights();
	// Material presets for lighting and shading
	void DefineObjectMaterials();
};
