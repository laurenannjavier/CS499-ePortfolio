// Enhanced ViewManager.h

// This header file handles the setup and manages th view camera view and projection
// matrices to control how the 3D scene is framed and navigated.

#pragma once  // Ensures this header file is only included once during compilation

// Include dependencies
#include "ShaderManager.h"    // Handles loading and managing GLSL shaders
#include "camera.h"           // Custom camera class for navigating the 3D scene
#include "GLFW/glfw3.h"       // GLFW library for window creation and input handling

// ViewManager class manages the OpenGL display window, scene viewing,
// camera control, and projection toggling between perspective and orthographic.
class ViewManager
{
public:
	// Constructor: takes a pointer to a ShaderManager instance
	ViewManager(ShaderManager* pShaderManager);

	// Destructor: cleans up dynamically allocated resources
	~ViewManager();

	// Static callback function for tracking mouse movement across the window
	// Used for camera rotation or interaction
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// Toggles between perspective and orthographic projection views
	void ToggleProjection();

private:
	// Pointer to the ShaderManager instance used to update/view shader state
	ShaderManager* m_pShaderManager;

	// Pointer to the GLFW window used to render the OpenGL context
	GLFWwindow* m_pWindow;

	// Processes user keyboard input for camera movement or scene changes
	void ProcessKeyboardEvents();

	// Keeps track of whether orthographic projection is currently active
	bool bOrthographicProjection;

public:
	// Creates and initializes the main display window with a given title
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);

	// Configures the view and projection matrices to render the 3D scene in 2D
	void PrepareSceneView();
};